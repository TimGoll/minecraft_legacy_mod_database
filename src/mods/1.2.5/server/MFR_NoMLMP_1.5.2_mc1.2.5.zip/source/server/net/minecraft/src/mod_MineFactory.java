package net.minecraft.src;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import net.minecraft.src.forge.*;
import net.minecraft.src.powercrystals.minefactoryreloaded.MineFactoryReloadedCore;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryFertilizable;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryHarvestable;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryPlantable;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryRanchable;
import net.minecraft.src.powercrystals.minefactoryreloaded.core.IMFRProxy;

public class mod_MineFactory extends NetworkMod implements IConnectionHandler, IPacketHandler
{	
	private static mod_MineFactory instance;
	
	public mod_MineFactory()
	{
		MineFactoryReloadedCore.Init(new ServerProxy());
		instance = this;
		
		MinecraftForge.registerConnectionHandler(this);
	}

	@Override
	public String getVersion()
	{
		return MineFactoryReloadedCore.version;
	}
	
	@Override
	public String getPriorities()
	{
		return "after:mod_BuildCraft*";
	}
	
	@Override
	public void modsLoaded()
	{
		MineFactoryReloadedCore.afterModsLoaded();
	}
	
	@Override
	public void load()
	{
	}
	
	public static void registerPlantable(IFactoryPlantable plantable)
	{
		MineFactoryReloadedCore.registerPlantable(plantable);
	}
	
	public static void registerHarvestable(IFactoryHarvestable harvestable)
	{
		MineFactoryReloadedCore.registerHarvestable(harvestable);
	}
	
	public static void registerFertilizable(IFactoryFertilizable fertilizable)
	{
		MineFactoryReloadedCore.registerFertilizable(fertilizable);
	}
	
	public static void registerFertilizerItem(int itemId)
	{
		MineFactoryReloadedCore.registerFertilizerItem(itemId);
	}
	
	public static void registerRanchable(IFactoryRanchable ranchable)
	{
		MineFactoryReloadedCore.registerRanchable(ranchable);
	}
	
	public class ServerProxy implements IMFRProxy
	{
		@Override
		public boolean isClient(World world)
		{
			return false;
		}

		@Override
		public boolean isServer()
		{
			return true;
		}

		@Override
		public void movePlayerToCoordinates(EntityPlayer e, double x, double y,	double z)
		{
			if(!(e instanceof EntityPlayerMP))
			{
				return;
			}
			((EntityPlayerMP)e).playerNetServerHandler.teleportTo(x, y, z, e.rotationYaw, e.rotationPitch);
		}

		@Override
		public int getBlockDamageDropped(Block block, int metadata)
		{
			return block.damageDropped(metadata);
		}

		@Override
		public int getRenderId()
		{
			return 0;
		}

		@Override
		public boolean fertilizeGiantMushroom(World world, int x, int y, int z)
		{
			int blockId = world.getBlockId(x, y, z);
			return ((BlockMushroom)Block.blocksList[blockId]).fertilizeMushroom(world, x, y, z, world.rand);
		}

		@Override
		public void fertilizeStemPlant(World world, int x, int y, int z)
		{
			int blockId = world.getBlockId(x, y, z);
			((BlockStem)Block.blocksList[blockId]).fertilizeStem(world, x, y, z);
		}

		@Override
		public String getConfigPath()
		{
			return "config/MineFactoryReloaded.cfg";
		}
		@Override
		public Packet getTileEntityPacket(TileEntity te, int[] dataInt, float[] dataFloat, String[] dataString)
		{
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream data = new DataOutputStream(bytes);
            try
            {
            	data.writeInt(te.xCoord);
            	data.writeInt(te.yCoord);
            	data.writeInt(te.zCoord);
            	
            	if (dataInt != null)
            	{
            		data.writeInt(dataInt.length);
                	for (int iterInt : dataInt)
                	{
                		data.writeInt(iterInt);
                	}
            	}
            	else
            	{
            		data.writeInt(0);
            	}
            	
            	if (dataFloat != null)
            	{
            		data.writeInt(dataFloat.length);
                	for (float iterFloat : dataFloat)
                	{
                		data.writeFloat(iterFloat);
                	}
            	}
            	else
            	{
            		data.writeInt(0);
            	}
            	
            	if (dataString != null)
            	{
            		data.writeInt(dataString.length);
                	for (String iterString : dataString)
                	{
                		data.writeUTF(iterString);
                	}
            	}
            	else
            	{
            		data.writeInt(0);
            	}
            }
            catch(IOException e)
            {
                    e.printStackTrace();
            }

            Packet250CustomPayload packet = new Packet250CustomPayload();
            packet.channel = MineFactoryReloadedCore.packetChannel;
            packet.data = bytes.toByteArray();
            packet.length = packet.data.length;

			return packet;
		}

		@Override
		public void sendPacketToAll(Packet p)
		{
			ModLoader.getMinecraftServerInstance().configManager.sendPacketToAllPlayers(p);
		}
		
	}

	@Override
	public void onPacketData(NetworkManager network, String channel, byte[] data)
	{
	}

	@Override
	public void onConnect(NetworkManager network)
	{
	}

	@Override
	public void onLogin(NetworkManager network, Packet1Login login)
	{
		MessageManager.getInstance().registerChannel(network, this, MineFactoryReloadedCore.packetChannel);
	}

	@Override
	public void onDisconnect(NetworkManager network, String message, Object[] args)
	{
	}

	@Override
	public boolean clientSideRequired()
	{
		return true;
	}

	@Override
	public boolean serverSideRequired()
	{
		return false;
	}
}
