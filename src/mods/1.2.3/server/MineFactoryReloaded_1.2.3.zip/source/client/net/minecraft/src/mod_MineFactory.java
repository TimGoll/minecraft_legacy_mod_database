package net.minecraft.src;

import net.minecraft.client.Minecraft;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.buildcraft.api.APIProxy;
import net.minecraft.src.forge.MinecraftForgeClient;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryFertilizable;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryHarvestable;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryPlantable;
import net.minecraft.src.powercrystals.minefactoryreloaded.api.IFactoryRanchable;
import net.minecraft.src.powercrystals.minefactoryreloaded.core.IMFRProxy;
import net.minecraft.src.powercrystals.minefactoryreloaded.core.Util;
import net.minecraft.src.powercrystals.minefactoryreloaded.FactoryRenderer;
import net.minecraft.src.powercrystals.minefactoryreloaded.MineFactoryReloadedCore;
import net.minecraft.src.powercrystals.minefactoryreloaded.MineFactoryReloadedCore.Machine;
import net.minecraft.src.powercrystals.minefactoryreloaded.TextureFrameAnimFX;
import net.minecraft.src.powercrystals.minefactoryreloaded.TextureLiquidFX;
import net.minecraft.src.powercrystals.minefactoryreloaded.TileEntityFactory;

public class mod_MineFactory extends BaseModMp
{
	public static int renderId = 1000;
	
	@Override
	public void load()
	{
		MineFactoryReloadedCore.Init(new ClientProxy());
		
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Planter)), "Planter");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Fisher)), "Fisher");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Harvester)), "Harvester");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Rancher)), "Rancher");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Fertilizer)), "Fertilizer");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Vet)), "Veterinary Station");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Collector)), "Item Collector");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Breaker)), "Block Breaker");
		ModLoader.addName(new ItemStack(MineFactoryReloadedCore.machineBlock, 1, MineFactoryReloadedCore.machineMetadataMappings.get(Machine.Weather)), "Weather Collector");
		
		ModLoader.addName(MineFactoryReloadedCore.conveyorBlock, "Conveyor Belt");
		
		ModLoader.addName(MineFactoryReloadedCore.passengerRailPickupBlock, "Passenger Pickup Rail");
		ModLoader.addName(MineFactoryReloadedCore.passengerRailDropoffBlock, "Passenger Dropoff Rail");
		ModLoader.addName(MineFactoryReloadedCore.cargoRailDropoffBlock, "Cargo Dropoff Rail");
		ModLoader.addName(MineFactoryReloadedCore.cargoRailPickupBlock, "Cargo Pickup Rail");
		
		ModLoader.addName(MineFactoryReloadedCore.steelIngotItem, "Steel Ingot");
		ModLoader.addName(MineFactoryReloadedCore.factoryHammerItem, "Factory Hammer");
		
		renderId = ModLoader.getUniqueBlockModelID(this, false);
	}
	
	@Override
	public void modsLoaded()
	{
		MinecraftForgeClient.preloadTexture(MineFactoryReloadedCore.terrainTexture);
		MinecraftForgeClient.preloadTexture(MineFactoryReloadedCore.itemTexture);
		MineFactoryReloadedCore.afterModsLoaded();
	}

	@Override
	public String getVersion()
	{
		return MineFactoryReloadedCore.version;
	}
	
	/** Force MFR to load after all other mods (since it uses BC API)
	  */
	@Override
	public String getPriorities() {
		return "after:*";
	}
		
	@Override
	public void registerAnimation(Minecraft minecraft)
	{
		if(Util.getBool(MineFactoryReloadedCore.animateBlockFaces))
		{
			ModLoader.addAnimation(new TextureFrameAnimFX(MineFactoryReloadedCore.conveyorTexture, "/MineFactorySprites/animations/Conveyor.png"));
			ModLoader.addAnimation(new TextureFrameAnimFX(MineFactoryReloadedCore.harvesterAnimatedTexture, "/MineFactorySprites/animations/Harvester.png"));
			ModLoader.addAnimation(new TextureFrameAnimFX(MineFactoryReloadedCore.rancherAnimatedTexture, "/MineFactorySprites/animations/Rancher.png"));
			ModLoader.addAnimation(new TextureFrameAnimFX(MineFactoryReloadedCore.blockBreakerAnimatedTexture, "/MineFactorySprites/animations/BlockBreaker.png"));
			ModLoader.addAnimation(new TextureFrameAnimFX(MineFactoryReloadedCore.fertilizerAnimatedTexture, "/MineFactorySprites/animations/Fertilizer.png"));
			ModLoader.addAnimation(new TextureFrameAnimFX(MineFactoryReloadedCore.vetAnimatedTexture, "/MineFactorySprites/animations/Vet.png"));
			ModLoader.addAnimation(new TextureLiquidFX(MineFactoryReloadedCore.milkTexture, MineFactoryReloadedCore.itemTexture, 240, 255, 240, 255, 230, 245));
		}
	}

	@Override
	public boolean renderWorldBlock(RenderBlocks renderblocks, IBlockAccess iblockaccess, int i, int j, int k, Block block, int renderId)
	{
		if(renderId == mod_MineFactory.renderId)
		{
			FactoryRenderer.renderConveyorWorld(renderblocks, iblockaccess, i, j, k, block, renderId);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@Override
    public void handleTileEntityPacket(int i, int j, int k, int l, int ai[], float af[], String as[])
    {
		World w = APIProxy.getWorld();
		TileEntity te = w.getBlockTileEntity(i, j, k);
		if(te != null && te instanceof TileEntityFactory)
		{
			((TileEntityFactory)te).rotateDirectlyTo(ai[0]);
		}
    }
	
	public static void registerPlantable(IFactoryPlantable plantable)
	{
		MineFactoryReloadedCore.registerPlantable(plantable);
	}
	
	public static void registerHarvestable(IFactoryHarvestable harvestable)
	{
		MineFactoryReloadedCore.registerHarvestable(harvestable);
	}
	
	public static void registerFertilizable(IFactoryFertilizable fertilizable)
	{
		MineFactoryReloadedCore.registerFertilizable(fertilizable);
	}
	
	public static void registerFertilizerItem(int itemId)
	{
		MineFactoryReloadedCore.registerFertilizerItem(itemId);
	}
	
	public static void registerRanchable(IFactoryRanchable ranchable)
	{
		MineFactoryReloadedCore.registerRanchable(ranchable);
	}
	
	public class ClientProxy implements IMFRProxy
	{

		@Override
		public boolean isClient(World world)
		{
			return world.isRemote;
		}

		@Override
		public boolean isServer()
		{
			return false;
		}

		@Override
		public void movePlayerToCoordinates(EntityPlayer e, double x, double y,	double z)
		{
			e.setPosition(x, y + 2.5, z);
		}

		@Override
		public int getBlockDamageDropped(Block block, int metadata)
		{
			return block.damageDropped(metadata);
		}

		@Override
		public int getRenderId()
		{
			return renderId;
		}

		@Override
		public boolean fertilizeGiantMushroom(World world, int x, int y, int z)
		{
			int blockId = world.getBlockId(x, y, z);
			return ((BlockMushroom)Block.blocksList[blockId]).fertilizeMushroom(world, x, y, z, world.rand);
		}

		@Override
		public void fertilizeStemPlant(World world, int x, int y, int z)
		{
			int blockId = world.getBlockId(x, y, z);
			((BlockStem)Block.blocksList[blockId]).fertilizeStem(world, x, y, z);
		}

		@Override
		public String getConfigPath()
		{
			return Minecraft.getMinecraftDir() + "/config/MineFactoryReloaded.cfg";
		}

		@Override
		public Packet getTileEntityPacket(TileEntity te, int[] dataInt, float[] dataFloat, String[] dataString)
		{
			return null;
		}

		@Override
		public void sendPacketToAll(Packet230ModLoader p)
		{	
		}
	}
}
